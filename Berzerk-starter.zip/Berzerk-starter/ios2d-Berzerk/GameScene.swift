//
//  GameScene.swift
//  ios2d-Berzerk
//
//  Created by Parrot on 2019-06-12.
//  Copyright © 2019 Parrot. All rights reserved.
//

import SpriteKit
import GameplayKit

class GameScene: SKScene, SKPhysicsContactDelegate {
    
    
    // player
    var player : SKNode!
    var enemiesArray : [SKNode] = []
    var evilOtto : SKNode!
   
    

    override func didMove(to view: SKView) {
        // Required for SKPhysicsContactDelegate
        self.physicsWorld.contactDelegate = self
        
        // get the sprites from SceneKit
        self.player = self.childNode(withName: "player")
        
        let e1 = self.childNode(withName: "enemy1")
        let e2 = self.childNode(withName: "enemy2")
        let e3 = self.childNode(withName: "enemy3")
        let e4 = self.childNode(withName: "enemy4")
        
        self.enemiesArray.append(e1!)
        self.enemiesArray.append(e2!)
        self.enemiesArray.append(e3!)
        self.enemiesArray.append(e4!)
        
        self.evilOtto = self.childNode(withName: "evilOtto")
        
    }
    
    // MARK: Function to notify us when two sprites touch
    func didBegin(_ contact: SKPhysicsContact) {
        
        let nodeA = contact.bodyA.node
        let nodeB = contact.bodyB.node
        
        if (nodeA!.name == "player" && nodeB!.name == "exit") {
            print("Player reached exit")
        
            
        // GAME WIN
        let messageLabel = SKLabelNode(text: "YOU WIN!")
        messageLabel.fontColor = UIColor.yellow
        messageLabel.fontSize = 60
        messageLabel.position.x = self.size.width/2
        messageLabel.position.y = self.size.height/2
        
        addChild(messageLabel)
        }
        
        if (nodeA!.name == "player" && nodeB!.name == "enemy1" ) {
            print("YOU LOSE FROM ENEMY 1")
            self.youLose()
            
            // Changing level from 1 to 2
            
            let level2Scene = SKScene(fileNamed:"Level02")
                       level2Scene!.scaleMode = .aspectFill
                        let flipTransition = SKTransition.flipVertical(withDuration: 2)
                            self.scene?.view?.presentScene(
                                    level2Scene!,
                                    transition: flipTransition)
        }
        if (nodeA!.name == "enemy1" && nodeB!.name == "player") {
            print("YOU LOSE FROM ENEMY 2")
            self.youLose()
            
            // Changing level from 1 to 2
            
            let level2Scene = SKScene(fileNamed:"Level02")
            level2Scene!.scaleMode = .aspectFill
            let flipTransition = SKTransition.flipVertical(withDuration: 2)
            self.scene?.view?.presentScene(
                level2Scene!,
                transition: flipTransition)
        }
        
        
        
    }
    
    var timeOfLastUpdate : TimeInterval = -1
    var startMovingEvilOtto : Bool = false
    override func update(_ currentTime: TimeInterval) {
        // Called before each frame is rendered
        self.moveEnemy()
        
        if timeOfLastUpdate == -1 {
            timeOfLastUpdate = currentTime
        }
        
        let timePassed = currentTime - timeOfLastUpdate
        if timePassed >= 5 {
            print("5 sec passed")
            timeOfLastUpdate = currentTime
            
            if startMovingEvilOtto == false {
                self.startMovingEvilOtto = true
            }
        }
        
        if startMovingEvilOtto == false {
            evilOtto.position.x = evilOtto.position.x - 10
        }
    }
    
    
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        let touch = touches.first
        if touch == nil {
            return
        }
        
        let mouseLocation = touch!.location(in: self)
        let spriteTouched = self.atPoint(mouseLocation)
        
        if spriteTouched.name == "up" {
            print("Pressed up button")
            self.player.position.y = self.player.position.y + 40
            
        } else if spriteTouched.name == "down" {
            print("Pressed down button")
            self.player.position.y = self.player.position.y - 40

        } else if spriteTouched.name == "left" {
            print("Pressed left button")
            self.player.position.x = self.player.position.x - 40

        } else if spriteTouched.name == "right" {
            print("Pressed right button")
            self.player.position.x = self.player.position.x + 40
        }
        
        
    }
    
    // Custom function
    
    func moveEnemy() {
        // loop through all your enemy nodes
        // for each node do the vector math calculation
        
        for(index, enemy) in self.enemiesArray.enumerated() {
//            print("Moving enemy \(index)")
        
        
        let a = self.player.position.x - enemy.position.x
        let b = self.player.position.y - enemy.position.y
        let d = sqrt(a * a + b * b)
        let xn = a / d
        let yn = b / d
        
        let ENEMY_SPEED : CGFloat = 2
        
        // update position
        enemy.position.x = enemy.position.x + xn * ENEMY_SPEED
        enemy.position.y = enemy.position.y + yn * ENEMY_SPEED
        }
        
    }
    
    func youLose() {
        // GAME WIN
        let messageLabel = SKLabelNode(text: "YOU Lose!")
        messageLabel.fontColor = UIColor.yellow
        messageLabel.fontSize = 60
        messageLabel.position.x = self.size.width/2
        messageLabel.position.y = self.size.height/2
        
    }
    
}
